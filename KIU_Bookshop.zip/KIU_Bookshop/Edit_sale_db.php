<?php
session_start();

// Include database connection
include 'php/DB_con.php'; // Ensure the path is correct

// Ensure the connection variable is set
if (!isset($conn)) {
    die("Database connection failed.");
}

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if the item_no is set
if (isset($_GET['item_no'])) {
    $item_no = $_GET['item_no'];

    // Fetch existing item details
    $sql = "SELECT * FROM sale_storage WHERE item_no = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }
    
    $stmt->bind_param("i", $item_no);
    if (!$stmt->execute()) {
        die("Execute failed: " . $stmt->error);
    }
    
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $item = $result->fetch_assoc();
    } else {
        echo "Item not found!";
        exit();
    }
} else {
    echo "No item selected!";
    exit();
}

// Handle the update form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $batch_no = $_POST['batch_no'];
    $item_name = $_POST['item_name'];
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];

    $sql = "UPDATE sale_storage SET batch_no = ?, item_name = ?, quantity = ?, price = ? WHERE item_no = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }
    
    $stmt->bind_param("ssidi", $batch_no, $item_name, $quantity, $price, $item_no);
    if ($stmt->execute()) {
        header("Location: http://localhost/KIU_BookShop/Sale_db.php");
        exit();
    } else {
        die("Error updating item: " . $stmt->error);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Item</title>
    <link rel="stylesheet" href="CSS/Edit_item.css">
</head>
<body>

<header class="header">
    <nav class="navbar">
        <a href="Add_item.php" class="nav-logo">KIU Book Shop</a>
        <ul class="nav-menu">
            <li class="nav-item"><a href="Add_item.php" class="nav-link">Add </a></li>
            <li class="nav-item"><a href="Update.php" class="nav-link">Update & delete</a></li>
            <li class="nav-item"><a href="Sale_db.php" class="nav-link">Sale Item</a></li>
            <li class="nav-item"><a href="php/logout.php" class="nav-link">Log Out</a></li>
        </ul>
        <div class="hamburger">
            <span class="bar"></span>
            <span class="bar"></span>
            <span class="bar"></span>
        </div>
    </nav>
</header><br><br>

<br><br><center><h1>Edit Item section</h1></center><br><br>

<form action="" method="post">

    <label for="item_name">Item Name:</label>
    <input type="text" name="item_name" id="item_name" value="<?php echo htmlspecialchars($item['item_name']); ?>" required><br><br>

    <label for="quantity">Quantity:</label>
    <input type="number" name="quantity" id="quantity" value="<?php echo htmlspecialchars($item['quantity']); ?>" required><br><br>

    <label for="price">Price:</label>
    <input type="number" step="0.01" name="price" id="price" value="<?php echo htmlspecialchars($item['price']); ?>" required><br><br>

    <button type="submit" class="btn btn-update">Save Changes</button>
</form>

</body>
</html>
