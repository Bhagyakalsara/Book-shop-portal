<?php
session_start();
include 'php/DB_con.php'; // Include database connection
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


// Redirect to login page if not logged in
if (!isset($_SESSION['admin_name'])) {
    header("Location: http://localhost/KIU_BookShop/Admin_Log&Reg.html");
    exit();
}

// Initialize variables
$item_details = [];
$show_form = true; // To control form visibility

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $item_no = $_POST['item_no'];
    $batch_no = $_POST['batch_no'];
    $item_name = $_POST['item_name'];
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];

    // Insert item into the database
    $sql = "INSERT INTO Main_storage (item_no, batch_no, item_name, quantity, price) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("issid", $item_no, $batch_no, $item_name, $quantity, $price);

    if ($stmt->execute()) {
        $show_form = false; // Hide form after successful submission
        // Fetch the saved item details
        $sql = "SELECT * FROM Main_storage WHERE item_no = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $item_no);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $item_details = $result->fetch_assoc();
        } else {
            echo "No item found with the given Item Number.";
        }
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Item - Admin Panel</title>
    <link rel="stylesheet" href="CSS/Admin_control.css">
    <script src="JS/form_visibility.js" defer></script>
</head>
<body>

<header class="header">
    <nav class="navbar">
        <a href="#" class="nav-logo">KIU Book Shop</a>
        <ul class="nav-menu">
            <li class="nav-item"><a href="Add_item.php" class="nav-link">Add </a></li>
            <li class="nav-item"><a href="Update.php" class="nav-link">Update & delete</a></li>
            <li class="nav-item"><a href="Sale_db.php" class="nav-link">Sale Item</a></li>
            <li class="nav-item"><a href="php/logout.php" class="nav-link">Log Out</a></li>
        </ul>
        <div class="hamburger">
            <span class="bar"></span>
            <span class="bar"></span>
            <span class="bar"></span>
        </div>
    </nav>
</header>

<br><br><br>
<center><h1 class="welcome">Welcome Admin <?php echo htmlspecialchars($_SESSION['admin_name']); ?>!</h1></center>

<?php if ($show_form): ?>
    <!-- Add Item Form -->
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
        <center><h1>Add New Item</h1></center>
        <label for="item_no">Item Number:</label>
        <input type="number" id="item_no" name="item_no" required><br><br>

        <label for="batch_no">Batch Number:</label>
        <input type="text" id="batch_no" name="batch_no" required><br><br>

        <label for="item_name">Item Name:</label>
        <input type="text" id="item_name" name="item_name" required><br><br>

        <label for="quantity">Quantity:</label>
        <input type="number" id="quantity" name="quantity" required><br><br>

        <label for="price">Price:</label>
        <input type="number" id="price" name="price" step="0.01" required><br><br>

        <center><button type="submit" name="action" value="add">Add Item</button></center>
    </form>
<?php else: ?>
    <!-- Display Saved Item Details -->
    <div class="item-details">
    <center><h2>Information about the item you just added</h2></center><br><br>
        <br><ul>
            <li><strong>Item No:</strong> <?php echo htmlspecialchars($item_details['item_no']); ?></li>
            <li><strong>Batch No:</strong> <?php echo htmlspecialchars($item_details['batch_no']); ?></li>
            <li><strong>Item Name:</strong> <?php echo htmlspecialchars($item_details['item_name']); ?></li>
            <li><strong>Quantity:</strong> <?php echo htmlspecialchars($item_details['quantity']); ?></li>
            <li><strong>Price:</strong> <?php echo htmlspecialchars($item_details['price']); ?></li>
        </ul>
        <br>
        <center><a href="Add_item.php" class="back-button">Back</a></center>
    </div>
    

<?php endif; ?>

<script>
const hamburger = document.querySelector(".hamburger");
const navMenu = document.querySelector(".nav-menu");

hamburger.addEventListener("click", mobileMenu);

function mobileMenu() {
    hamburger.classList.toggle("active");
    navMenu.classList.toggle("active");
}

const navLink = document.querySelectorAll(".nav-link");

navLink.forEach(n => n.addEventListener("click", closeMenu));

function closeMenu() {
    hamburger.classList.remove("active");
    navMenu.classList.remove("active");
}
</script>
</body>
</html>
