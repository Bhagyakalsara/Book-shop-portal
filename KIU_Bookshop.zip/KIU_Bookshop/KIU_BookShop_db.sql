CREATE DATABASE KIU_BookShop_db;

USE `KIU_BookShop_db`;
CREATE TABLE IF NOT EXISTS main_storage (
    id INT AUTO_INCREMENT PRIMARY KEY,
    item_name VARCHAR(255) NOT NULL UNIQUE,
    quantity INT NOT NULL,
    item_type ENUM('book', 'pen', 'pencil', 'half-sheet') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

USE `KIU_BookShop_db`;
CREATE TABLE Main_storage (
    item_no INT PRIMARY KEY,                 -- Item No as the primary key
    batch_no VARCHAR(50),                    -- Item Batch No
    item_name VARCHAR(100) NOT NULL,         -- Item Name
    quantity INT NOT NULL,                   -- Quantity of the item
    price DECIMAL(10, 2) NOT NULL,           -- Price of the item
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,  -- Date and time of entry
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP  -- Date and time of last update
);

USE KIU_BookShop_db;

CREATE TABLE admin_info (
    name VARCHAR(255) NOT NULL,
    nic VARCHAR(20) NOT NULL PRIMARY KEY,
    password VARCHAR(255) NOT NULL,
    confirm_password VARCHAR(255) NOT NULL
);
USE `KIU_BookShop_db`;

CREATE TABLE sale_storage (
    sale_id INT AUTO_INCREMENT PRIMARY KEY, -- Unique identifier for each sale entry
    item_no INT,                           -- Item Number (foreign key from main_storage)
    batch_no VARCHAR(50),                  -- Batch Number of the item
    item_name VARCHAR(100) NOT NULL,       -- Item Name
    quantity INT NOT NULL,                 -- Quantity sold
    price DECIMAL(10, 2) NOT NULL,         -- Price of the item
    sale_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- Date and time of sale
    FOREIGN KEY (item_no) REFERENCES main_storage(item_no) -- Foreign key constraint
);
