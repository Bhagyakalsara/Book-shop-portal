<?php
session_start();
session_unset();
session_destroy();
header("Location: http://localhost/KIU_BookShop/Admin_Log&Reg.html"); // Redirect to login page
exit();
?>
