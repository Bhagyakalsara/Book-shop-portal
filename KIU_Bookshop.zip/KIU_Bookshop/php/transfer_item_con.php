<?php
include 'DB_con.php'; // Include your database connection file

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $item_no = $_POST['item_no'];
    $quantity = $_POST['quantity'];

    // Check if item exists in main_storage
    $sql = "SELECT batch_no, item_name, quantity, price FROM main_storage WHERE item_no = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $item_no);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $item = $result->fetch_assoc();

        if ($quantity > $item['quantity']) {
            echo "Error: Quantity exceeds available stock.";
            exit();
        }

        // Insert into sale_storage
        $sql = "INSERT INTO sale_storage (item_no, batch_no, item_name, quantity, price) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("issid", $item_no, $item['batch_no'], $item['item_name'], $quantity, $item['price']);
        $stmt->execute();

        // Update quantity in main_storage
        $sql = "UPDATE main_storage SET quantity = quantity - ? WHERE item_no = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $quantity, $item_no);
        $stmt->execute();

        echo "Goods transferred successfully!";
        header("Location: http://localhost/KIU_BookShop/transfer_item.html"); 
    } else {
        echo "Error: Item not found.";
    }
} else {
    echo "Invalid request.";
}
?>
