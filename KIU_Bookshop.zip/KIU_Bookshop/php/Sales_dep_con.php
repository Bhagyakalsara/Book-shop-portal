<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "1234";
$dbname = "KIU_BookShop_db";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the data from the request
$data = json_decode(file_get_contents('php://input'), true);

if (is_array($data)) {
    $stmt = null; // Initialize $stmt to avoid "undefined variable" error

    foreach ($data as $item) {
        $item_no = $item['item_no'];
        $requested_quantity = $item['quantity'];

        // Check stock in sale_storage
        $stock_check_query = "SELECT quantity FROM sale_storage WHERE item_no = ?";
        $stmt = $conn->prepare($stock_check_query);
        if (!$stmt) {
            echo json_encode(['success' => false, 'message' => 'Error preparing stock check query: ' . $conn->error]);
            exit();
        }
        $stmt->bind_param("s", $item_no);
        $stmt->execute();
        $stmt->bind_result($available_quantity);
        $stmt->fetch();
        $stmt->close();

        if ($available_quantity < $requested_quantity) {
            echo json_encode(['success' => false, 'message' => 'Insufficient stock in sale_storage']);
            exit();
        }

        // Update stock in sale_storage
        $update_stock_query = "UPDATE sale_storage SET quantity = quantity - ? WHERE item_no = ?";
        $stmt = $conn->prepare($update_stock_query);
        if (!$stmt) {
            echo json_encode(['success' => false, 'message' => 'Error preparing stock update query: ' . $conn->error]);
            exit();
        }
        $stmt->bind_param("is", $requested_quantity, $item_no);

        if (!$stmt->execute()) {
            echo json_encode(['success' => false, 'message' => 'Error updating stock: ' . $stmt->error]);
            $stmt->close();
            exit();
        }

        // Remove item from sale_storage if quantity is 0
        $delete_zero_stock_query = "DELETE FROM sale_storage WHERE item_no = ? AND quantity <= 0";
        $stmt = $conn->prepare($delete_zero_stock_query);
        if (!$stmt) {
            echo json_encode(['success' => false, 'message' => 'Error preparing delete query: ' . $conn->error]);
            exit();
        }
        $stmt->bind_param("s", $item_no);
        $stmt->execute();
        $stmt->close();

        // Insert sale into sales_db
        $insert_sale_query = "INSERT INTO sales_db (item_no, item_name, quantity, price, sale_date) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insert_sale_query);
        if (!$stmt) {
            echo json_encode(['success' => false, 'message' => 'Error preparing sale insert query: ' . $conn->error]);
            exit();
        }
        $sale_date = date('Y-m-d H:i:s');
        $stmt->bind_param("ssids", $item_no, $item['item_name'], $requested_quantity, $item['price'], $sale_date);

        if (!$stmt->execute()) {
            echo json_encode(['success' => false, 'message' => 'Error processing sale: ' . $stmt->error]);
            $stmt->close();
            exit();
        }

        $stmt->close(); // Close after each successful execution
    }

    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid data']);
}

$conn->close();
?>
