<?php
include 'DB_con.php';

$sql1 = "DELETE FROM sales_db";

if ($conn->query($sql1) === TRUE) {
    echo "All data deleted successfully.";
} else {
    echo "Error deleting data: " . $conn->error;
}

$conn->close();
header("Location: http://localhost/KIU_BookShop/Sale_db.php"); // Redirect back to Sale_db.php after deletion
exit();
?>
