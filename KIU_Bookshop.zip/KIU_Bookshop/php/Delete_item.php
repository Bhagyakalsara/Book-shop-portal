<?php
session_start();

// Include database connection
include 'DB_con.php'; // Ensure this path is correct

// Ensure the connection variable is set
if (!isset($conn)) {
    die("Database connection failed.");
}

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the item_no is set
if (isset($_POST['item_no'])) {
    $item_no = $_POST['item_no'];

    // Start a transaction
    $conn->begin_transaction();

    try {
        // Delete from sale_storage
        $deleteSaleSql = "DELETE FROM sale_storage WHERE item_no = ?";
        $deleteSaleStmt = $conn->prepare($deleteSaleSql);
        if (!$deleteSaleStmt) {
            throw new Exception("Prepare failed: " . $conn->error);
        }

        $deleteSaleStmt->bind_param("i", $item_no);
        if (!$deleteSaleStmt->execute()) {
            throw new Exception("Error deleting from sale_storage: " . $deleteSaleStmt->error);
        }

        // Delete from main_storage
        $deleteMainSql = "DELETE FROM main_storage WHERE item_no = ?";
        $deleteMainStmt = $conn->prepare($deleteMainSql);
        if (!$deleteMainStmt) {
            throw new Exception("Prepare failed: " . $conn->error);
        }

        $deleteMainStmt->bind_param("i", $item_no);
        if (!$deleteMainStmt->execute()) {
            throw new Exception("Error deleting from main_storage: " . $deleteMainStmt->error);
        }

        // Commit the transaction
        $conn->commit();

        // Redirect back to the Update page after successful deletion
        header("Location: ../Update.php");
        exit();

    } catch (Exception $e) {
        // Rollback the transaction on error
        $conn->rollback();
        die("Transaction failed: " . $e->getMessage());
    }

} else {
    echo "No item selected for deletion!";
    exit();
}

$conn->close();
?>
