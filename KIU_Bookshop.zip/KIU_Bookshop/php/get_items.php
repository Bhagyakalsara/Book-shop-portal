<?php
include 'DB_con.php'; // Include the database connection script

// Fetch items from the database
$sql = "SELECT item_no, item_name, quantity, price FROM sale_storage";
$result = $conn->query($sql);

$items = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Ensure that the quantity is correctly formatted as integer
        $items[] = array(
            'item_no' => $row['item_no'],
            'item_name' => $row['item_name'],
            'quantity' => (int)$row['quantity'], // Ensure quantity is an integer
            'price' => (float)$row['price'] // Ensure price is a float
        );
    }
} else {
    $items = array();
}

echo json_encode($items);

$conn->close();
?>
