<?php
include 'DB_con.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $quantity = $_POST['quantity'];
    $type = $_POST['type'];
    $action = $_POST['action'];

    if ($action == 'add') {
        $sql = "INSERT INTO main_storage (item_name, quantity, item_type) VALUES ('$name', $quantity, '$type')";
    } elseif ($action == 'update') {
        $sql = "UPDATE main_storage SET quantity = $quantity, item_type = '$type', updated_at = CURRENT_TIMESTAMP WHERE item_name = '$name'";
    } elseif ($action == 'delete') {
        $sql = "DELETE FROM main_storage WHERE item_name = '$name'";
    }

    if ($conn->query($sql) === TRUE) {
        echo "Record $action successfully";
    } else {
        echo "Error: " . $conn->error;
    }

    $conn->close();
}
?>
