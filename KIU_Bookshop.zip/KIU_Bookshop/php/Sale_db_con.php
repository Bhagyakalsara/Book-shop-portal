<?php
include 'DB_con.php'; // Include database connection
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Remove items with quantity of 0
$delete_zero_quantity_query = "DELETE FROM sale_storage WHERE quantity <= 0";
if (!$conn->query($delete_zero_quantity_query)) {
    echo "Error removing zero quantity items: " . $conn->error;
}

// Fetch and display remaining items
$sql = "SELECT * FROM sale_storage";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['item_no']}</td>
                <td>{$row['batch_no']}</td>
                <td>{$row['item_name']}</td>
                <td>{$row['quantity']}</td>
                <td>Rs: {$row['price']}</td>
                <td>{$row['sale_date']}</td>
                <td>
                    <a href='Edit_sale_db.php?item_no=" . urlencode($row['item_no']) . "' class='btn btn-update'>Update</a>
                </td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='7'>No data available</td></tr>";
}

// Calculate daily income from `sales_db` and percentage of total sales
$income_query = "SELECT DATE(sale_date) as date, SUM(price * quantity) as total_income 
                 FROM sales_db
                 GROUP BY DATE(sale_date)";
$income_result = $conn->query($income_query);

// Calculate total income from `sales_db`
$total_income_query = "SELECT SUM(price * quantity) as total_income FROM sales_db";
$total_income_result = $conn->query($total_income_query);
$total_income_row = $total_income_result->fetch_assoc();
$total_income = $total_income_row['total_income'];

if ($income_result->num_rows > 0) {
    echo "<br>";
    echo "<br>";
    echo "<br>";
    echo "<table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Daily Income (Rs)</th>
                    <th>Percentage of Total Sales</th>
                </tr>
            </thead>
            <tbody>";

    while($income_row = $income_result->fetch_assoc()) {
        $daily_income = $income_row['total_income'];
        $percentage = ($total_income > 0) ? ($daily_income / $total_income) * 100 : 0;
        echo "<tr>
                <td>{$income_row['date']}</td>
                <td>Rs: " . number_format($daily_income, 2) . "</td>
                <td>" . number_format($percentage, 2) . "%</td>
              </tr>";
    }
    
    echo "</tbody></table>";
} else {
    echo "<h3><center>No data available for daily sales percentage.</center></h3><br>";
}

$conn->close();
?>
