<?php
require_once 'DB_con.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Start session at the beginning of the script
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST['action'];

    if ($action == 'register') {
        $name = $_POST['name'];
        $nic = $_POST['nic'];
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password']; // Get the confirm password field

        // Check if passwords match
        if ($password === $confirm_password) {
            // Hash the password for security
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Prepare and execute the SQL statement to insert user data
            $sql = "INSERT INTO admin_info (name, nic, password) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sss", $name, $nic, $hashed_password);

            if ($stmt->execute()) {
                echo "Registration successful!";
                header("Location: http://localhost/KIU_BookShop/Admin_Log&Reg.html");
                exit(); // Ensure script stops after redirect
            } else {
                echo "Error: " . $stmt->error;
            }

            $stmt->close();
        } else {
            echo "Passwords do not match.";
        }
    } elseif ($action == 'login') {
        $nic = $_POST['nic'];
        $password = $_POST['password'];

        // Prepare and execute the SQL statement to check user credentials
        $sql = "SELECT * FROM admin_info WHERE nic = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $nic);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if (password_verify($password, $row['password'])) {
                // Start the session and store admin info
                session_start();
                $_SESSION['admin_name'] = $row['name'];
                header("Location: http://localhost/KIU_BookShop/Add_item.php");
                exit(); // Ensure script stops after redirect
            } else {
                echo "Incorrect password.";
            }
        } else {
            echo "User not found.";
        }

        $stmt->close();
    }
}

$conn->close();
?>
