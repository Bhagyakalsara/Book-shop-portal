<?php
include 'DB_con.php'; // Include database connection
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM main_storage";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['item_no']}</td>
                <td>{$row['batch_no']}</td>
                <td>{$row['item_name']}</td>
                <td>{$row['quantity']}</td>
                <td>Rs: {$row['price']}</td>
                <td>{$row['created_at']}</td>
                <td>{$row['updated_at']}</td>
                <td>
                    <a href='Edit_item.php?item_no=" . urlencode($row['item_no']) . "' class='btn btn-update'>Update</a>
                    <form action='php/Delete_item.php' method='post' style='display:inline;'>
                        <input type='hidden' name='item_no' value='" . htmlspecialchars($row['item_no']) . "'>
                        <button type='submit' class='btn btn-delete'>Delete</button>
                    </form>
                </td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='6'>No data available</td></tr>";
}

$conn->close();
?>
