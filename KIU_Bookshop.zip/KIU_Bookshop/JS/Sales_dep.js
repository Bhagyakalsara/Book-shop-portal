document.addEventListener('DOMContentLoaded', function() {
    console.log("JavaScript Loaded Successfully");

    let cart = [];
    let totalPrice = 0;

    fetch('php/get_items.php')
        .then(response => response.json())
        .then(data => {
            console.log('Items fetched from server:', data);
            data.forEach(item => {
                item.price = parseFloat(item.price);
                item.quantity = parseInt(item.quantity);
                if (isNaN(item.price) || isNaN(item.quantity)) {
                    console.error(`Invalid value from server for item ${item.item_name}`);
                }
            });
            displayItems(data);
        })
        .catch(error => console.error('Error fetching items:', error));

    function displayItems(items) {
        const itemsContainer = document.getElementById('items');
        
        if (items.length === 0) {
            itemsContainer.innerHTML = '<p>No items available for sale.</p>';
            console.log("No items available.");
            return;
        }
    
        console.log("Items available:", items);
    
        items.forEach(item => {
            console.log("Adding item:", item);
            
            const price = parseFloat(item.price);
            const quantity = parseInt(item.quantity);
            
            if (isNaN(price) || isNaN(quantity)) {
                console.error(`Invalid price or quantity for item ${item.item_name}: ${item.price}, ${item.quantity}`);
                return;
            }
    
            const itemBox = document.createElement('div');
            itemBox.className = 'item-box';
            itemBox.innerHTML = `
                <b><p>${item.item_name}</p></b><br>
                <p>Rs :<b>${price.toFixed(2)}</b></p><br>
                <p>Quantity: <b>${quantity}</b></p>`;
            itemBox.addEventListener('click', () => addToCart(item));
            itemsContainer.appendChild(itemBox);
        });
    }

    function addToCart(item) {
        console.log('Adding item to cart:', item);
        item.price = parseFloat(item.price);
        if (isNaN(item.price)) {
            console.error(`Invalid price value for item ${item.item_name}`);
            return;
        }

        if (item.quantity <= 0) {
            alert('Item out of stock! Get from main store');
            return;
        }

        const existingItem = cart.find(cartItem => cartItem.item_no === item.item_no);
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({ ...item, quantity: 1 });
        }

        updateCart();
    }

    function updateCart() {
        const cartItemsContainer = document.getElementById('cart-items');
        cartItemsContainer.innerHTML = '';
        totalPrice = 0;

        cart.forEach(cartItem => {
            const price = parseFloat(cartItem.price);
            const quantity = cartItem.quantity;
            console.log(`Price for item ${cartItem.item_name}:`, price);
            if (isNaN(price)) {
                console.error(`Invalid price value for item ${cartItem.item_name}`);
                return;
            }

            const listItem = document.createElement('li');
            listItem.textContent = `${cartItem.item_name} - Rs ${price.toFixed(2)} x ${quantity}`;
            cartItemsContainer.appendChild(listItem);
            totalPrice += price * quantity;
        });

        document.getElementById('total-price').textContent = `Total: Rs ${totalPrice.toFixed(2)}`;
    }

    document.getElementById('sale-button').addEventListener('click', function() {
        if (cart.length > 0) {
            fetch('php/Sales_dep_con.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(cart)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    cart = [];
                    updateCart();
                    window.location.href = 'http://localhost/KIU_BookShop/Sales_dep.html'; // Redirect after success
                } else {
                    alert('Error processing sale: ' + data.message);
                }
            })
            .catch(error => console.error('Error processing sale:', error));
        } else {
            alert('No items in the cart.');
        }
    });
});
