const hamburger = document.querySelector(".hamburger");
const navMenu = document.querySelector(".nav-menu");

hamburger.addEventListener("click", mobileMenu);

function mobileMenu() {
    hamburger.classList.toggle("active");
    navMenu.classList.toggle("active");
}

// Close the menu when a nav link is clicked
const navLink = document.querySelectorAll(".nav-link");

navLink.forEach(n => n.addEventListener("click", closeMenu));

function closeMenu() {
    hamburger.classList.remove("active");
    navMenu.classList.remove("active");
}

// Sample data for Database A
const dbAItems = [
    { id: 1, name: 'Item 1', quantity: 10 },
    { id: 2, name: 'Item 2', quantity: 5 },
    { id: 3, name: 'Item 3', quantity: 8 },
    { id: 4, name: 'Item 4', quantity: 2 }
];

// Database B (empty initially)
const dbBItems = [];

document.addEventListener('DOMContentLoaded', function() {
    const dbAList = document.getElementById('dbAItems');
    const dbBList = document.getElementById('dbBItems');
    const transferButton = document.getElementById('transferButton');

    // Populate Database A items
    dbAItems.forEach(item => {
        const li = document.createElement('li');
        li.textContent = `${item.name} (Quantity: ${item.quantity})`;
        li.dataset.id = item.id;
        li.addEventListener('click', () => {
            li.classList.toggle('selected');
        });
        dbAList.appendChild(li);
    });

    // Transfer selected items from Database A to Database B
    transferButton.addEventListener('click', () => {
        const selectedItems = dbAList.querySelectorAll('.selected');
        
        selectedItems.forEach(item => {
            const itemId = parseInt(item.dataset.id);
            const itemData = dbAItems.find(i => i.id === itemId);
            
            // Remove from dbAItems
            const itemIndex = dbAItems.indexOf(itemData);
            dbAItems.splice(itemIndex, 1);

            // Add to dbBItems
            dbBItems.push(itemData);

            // Remove item from the list in Database A
            item.remove();

            // Add item to the list in Database B with timestamp
            const li = document.createElement('li');
            const currentTime = new Date().toLocaleString();
            li.innerHTML = `${itemData.name} (Quantity: ${itemData.quantity})
                            <div class="time-stamp">Transferred on: ${currentTime}</div>`;
            dbBList.appendChild(li);
        });
    });
});
