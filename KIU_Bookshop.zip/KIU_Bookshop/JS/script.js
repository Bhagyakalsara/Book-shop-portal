document.addEventListener('DOMContentLoaded', () => {
    const hamburger = document.querySelector(".hamburger");
    const navMenu = document.querySelector(".nav-menu");
    const navLinks = document.querySelectorAll(".nav-link");
    const actionDropdown = document.getElementById('action');
    const addSection = document.getElementById('addSection');
    const updateSection = document.getElementById('updateSection');
    const deleteSection = document.getElementById('deleteSection');

    // Ensure elements exist before adding event listeners
    if (hamburger && navMenu && actionDropdown && addSection && updateSection && deleteSection) {

        // Toggle the mobile menu when the hamburger icon is clicked
        hamburger.addEventListener("click", toggleMobileMenu);

        // Close the mobile menu when a navigation link is clicked
        navLinks.forEach(link => link.addEventListener("click", closeMobileMenu));

        // Trigger the toggleFormSections function when the action dropdown changes
        actionDropdown.addEventListener('change', toggleFormSections);
    }

    function toggleMobileMenu() {
        hamburger.classList.toggle("active");
        navMenu.classList.toggle("active");
    }

    function closeMobileMenu() {
        hamburger.classList.remove("active");
        navMenu.classList.remove("active");
    }

    function toggleFormSections() {
        const action = actionDropdown.value;

        // Hide all sections initially
        addSection.style.display = 'none';
        updateSection.style.display = 'none';
        deleteSection.style.display = 'none';

        // Show the appropriate section based on the selected action
        if (action === 'add') {
            addSection.style.display = 'block';
        } else if (action === 'update') {
            updateSection.style.display = 'block';
        } else if (action === 'delete') {
            deleteSection.style.display = 'block';
        }
    }
});
