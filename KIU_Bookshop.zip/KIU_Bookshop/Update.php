<?php
session_start();
include 'php/DB_con.php'; // Include database connection
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


// Redirect to login page if not logged in
if (!isset($_SESSION['admin_name'])) {
    header("Location: http://localhost/KIU_BookShop/Admin_Log&Reg.html");
    exit();
}

// Initialize variables
$item_details = [];
$show_form = true; // To control form visibility
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bookshop Inventory</title>
    <link rel="stylesheet" href="CSS/Update.css">
</head>
<body>

<header class="header">
        <nav class="navbar">
            <a href="Add_item.php" class="nav-logo">KIU Book Shop</a>
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="Add_item.php" class="nav-link">Add</a>
                </li>
                <li class="nav-item">
                    <a href="Update.php" class="nav-link">Update & delete</a>
                </li>
                <li class="nav-item">
                    <a href="Sale_db.php" class="nav-link">Sale Item</a>
                </li>
                <li class="nav-item">
                    <a href="php/logout.php" class="nav-link">Log Out</a>
                </li>
            </ul>
            <div class="hamburger">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </div>
        </nav>
</header><br>

<br><center><h1 class="welcome">Welcome <?php echo htmlspecialchars($_SESSION['admin_name']); ?>!</h1></center><br><BR><BR>


    <br><table>
        <thead>
            <tr>
                <th>Item No</th>
                <th>Batch No</th>
                <th>Item Name</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Created at</th>
                <th>Updated at</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <!-- Data rows will be included here from the PHP file -->
            <?php include 'php/Update_del_con.php'; ?>
        </tbody>
    </table>
<script>
const hamburger = document.querySelector(".hamburger");
const navMenu = document.querySelector(".nav-menu");

hamburger.addEventListener("click", mobileMenu);

function mobileMenu() {
    hamburger.classList.toggle("active");
    navMenu.classList.toggle("active");
}

const navLink = document.querySelectorAll(".nav-link");

navLink.forEach(n => n.addEventListener("click", closeMenu));

function closeMenu() {
    hamburger.classList.remove("active");
    navMenu.classList.remove("active");
}
</script>
</body>
</html>
